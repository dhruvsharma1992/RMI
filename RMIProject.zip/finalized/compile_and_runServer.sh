javac pingpongserverTest/*.java

java pingpongserverTest/PingServerFactory

